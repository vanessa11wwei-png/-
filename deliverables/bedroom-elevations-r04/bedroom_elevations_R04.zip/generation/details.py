# Executed by build.py; all detail coordinates below are true millimetres.
def interior(v,w,n,h=2400,label='',source='',depth=620):
 b=18;kick=80
 v.rect(0,0,w,h,'A-OUTLINE')
 v.rect(0,kick,w,b,'A-DETAIL','section');v.rect(0,h-b,w,b,'A-DETAIL','section')
 v.rect(0,kick,b,h-kick,'A-DETAIL','section');v.rect(w-b,kick,b,h-kick,'A-DETAIL','section')
 bounds=[round(w*i/n) for i in range(n+1)]
 divs=[(x-9,x+9) for x in bounds[1:-1]]
 for a,bb in divs:v.rect(a,98,b,h-98-b,'A-DETAIL','section')
 clear=[(18,divs[0][0])]+[(divs[i-1][1],divs[i][0]) for i in range(1,n-1)]+[(divs[-1][1],w-18)]
 v.rect(18,1980,w-36,18,'A-DETAIL','section')
 for i,(a,bb) in enumerate(clear):
  cw=bb-a
  if i in [0,n-1] or depth<=300:
   for yy in [520,950,1380,1750]:v.rect(a,yy,cw,18,'A-DETAIL','section')
  else:
   v.line((a+30,1780),(bb-30,1780),'A-SYMBOL')
   for yy in [300,500]:v.rect(a+8,yy,cw-16,160,'A-DETAIL');v.handle((a+bb)/2,yy+80)
  v.dx(a,bb,2150,1980,status='D',source='原外宽减18板件，柜厂校核',component=label+'_clear')
  txt(m,*v.p(((a+bb)/2,2260)),f'{i+1:02}',2.5*v.s,align=TextEntityAlignment.CENTER)
 v.dx(0,w,-180,status='P',source=source)
 v.dy(w+140,0,h,base=w,status='D',source='建议柜高2400')
 v.dy(-130,98,1980,base=0,status='D',source='下柜实际净高计算')
 v.detail(100,140,'D01');v.detail(w-100,2380,'D02')
 widths=[bb-a for a,bb in clear]
 assert abs(sum(widths)+(n+1)*18-w)<1e-6
 COMPONENTS.append({'sheet':v.sheet,'kind':label+'_内部','outer_P':w,'depth_P':depth,
    'source':source,'module_centerlines_D':bounds,'clear_widths_D':widths,
    'side_and_divider_boards_D':n+1,'board_D':18,'width_closure':sum(widths)+(n+1)*18,
    'lower_clear_height_D':1882,'upper_clear_height_D':384})
 return widths

def cabinet_section(v,depth=620,h=2400):
 v.rect(0,80,depth-21,18,'A-OUTLINE','section')
 v.rect(0,h-18,depth-21,18,'A-OUTLINE','section')
 v.rect(0,98,9,h-116,'A-DETAIL','section')
 v.rect(depth-18,80,18,h-80,'A-OUTLINE','section')
 v.rect(depth-110,0,18,80,'A-DETAIL','section')
 for yy in [500,950,1380,1980]:v.rect(9,yy,depth-30,18,'A-DETAIL','section')
 v.dx(0,depth,-170,status='P',source='柜体平面进深')
 v.dy(depth+120,0,80,base=depth,status='D',source='踢脚高')
 v.dy(depth+120,80,98,base=depth,status='D',source='底板厚18')
 v.txt(30,h+110,'背板9、前缝3、门板18均D')

for j,(code,title,w,n,depth,src) in enumerate([
 ('JB-01','女儿房衣柜 / 内部及侧剖',2565,5,620,'91CE'),
 ('JB-02','男孩房衣柜 / 内部及侧剖',1720,3,600,'90EB')]):
 ps=sheet(code,title,'P外轮廓保留；板厚、净格、内部功能均为D建议；门板下料需柜厂复核','1:15')
 v=View(230000+j*14000,0,15,code);clear=interior(v,w,n,label=title.split(' /')[0],source=src,depth=depth)
 sv=View(230000+j*14000+6000,0,15,code);cabinet_section(sv,depth)
 viewport(ps,v,(120,160),(199,190),(w/2,1200),15)
 viewport(ps,sv,(282,160),(105,190),(depth/2,1200),15)
 txt(ps,24,62,'01 内部展开 1:15',3,'S-TEXT');txt(ps,238,62,'02 侧剖 1:15',3,'S-TEXT')
 lines(ps,345,245,['板厚18[D]。','上口净空384[D]。','下柜净高1882[D]。',
  '背板9[D]。','门板18[D]。','前缝3[D]。','层板、挂杆与抽屉均属建议。',
  '固定件、载荷、五金选型另核。','H未定，柜顶收口可调。'],width=20,h=2.5,leading=4)
 if j==1:lines(ps,345,115,['门扇与柜轮廓相距20[P]。','该余量不足以直接确定门套和侧封板，须现场协调。'],width=20,h=2.5,leading=4)
 grid(ps,20,54,[35,140,205],[['外轮廓P',str(w)+' × '+str(depth),'仅外宽、进深为P；高2400为D'],
     ['净格D',' / '.join(str(round(a)) for a in clear),'净格总和 + '+str(n+1)+'块18板 = '+str(w)]],row_h=12)

ps=sheet('JB-03','薄柜与玩具柜 / 内部功能深化','薄柜进深300；玩具柜源图进深200，收纳篮选型可能需要另改进深','详见各图')
v=View(260000,0,20,'JB-03');interior(v,2400,4,label='次卧薄柜',source='9AD2',depth=300)
viewport(ps,v,(106,173),(176,167),(1200,1200),20)
txt(ps,25,82,'次卧薄柜内部 / 1:20 / 仅层板储物',3,'S-TEXT')
sv=View(266000,0,10,'JB-03');shelf(sv,0,3100,600,2,'男孩房玩具柜内部','913D')
sv.dx(0,3100,-140,status='P',source='913D宽3100')
sv.dy(3300,0,600,base=3100,status='D',source='按P67矮柜意向建议')
viewport(ps,sv,(299,189),(190,127),(1550,300),20)
txt(ps,210,112,'玩具矮柜 / 1:20',3,'S-TEXT')
lines(ps,210,100,['源平面深200[P]，本版不擅自改深以容纳效果图篮筐。',
 '若保留该进深，仅适合薄书或浅件；需按篮筐实物与通行净距再定。',
 '两层与分格属D；层板18，跨距及固定按实际载荷校核。'],width=70,h=2.7,leading=4.5)
lines(ps,20,60,['薄柜：4个600定位模数；净格573/582/582/573[D]，两侧及隔板均18[D]。',
 '玩具柜：外宽3100[P]；五格净宽均598.4[D]，共6块18板，闭合3100。'],width=133,h=2.7,leading=5)

NODE_INFO={
 'D01':('柜底 / 调节脚 / 踢脚',5,['底板18、门板18、踢脚80均D。','踢脚退后60[D]；调节脚形态仅示意。',
    '底板经调节脚传力至完成地面；不可只靠踢脚板承托。','调节脚及底板承载、固定件型号/间距由柜厂复核。','原地面及完成厚度U，现场找平后复尺。']),
 'D02':('柜顶 / 可调封板 / 顶面',5,['柜高2400为D；顶部剩余高度由实测H扣算。','上封板与顶面设置可调整的收边关系。',
    '角码及螺钉只表达固定位置，规格和间距另核。','吊顶不得作为高柜唯一固定基层。','未核梁底及检修空间前，不确定封板下料高。']),
 'D03':('门板分缝 / 侧板 / 五金',2,['门板18、侧板18、门缝3均D。','覆门形式按示意；杯铰链、覆盖量与封边共同复核。',
    '定位模数不等于门板净宽；不得用图面分格直接下料。','男孩房门套邻柜仅20[P]，侧封板及开启需协调。']),
 'D04':('织物软饰面 / 基层 / 木边框',2,['建议软饰层10+基层12[D]，沿墙铺设。','木边框与软饰面之间留3[D]控制缝。',
    '基层固定到原墙可用基层，禁止只粘于松散面层。','固定及防火要求随样板、基层和产品体系确认。','效果图的织物与木边关系保留，材质样板仍待确认。']),
 'D05':('原窗框 / 窗套 / 墙面收边',2,['窗套基层及饰面合计12[D]；框边控制缝3[D]。','密封材料与原窗框兼容，保留排水及检修空间。',
    '不以饰面压住原窗开启、压线或排水构件。','原墙厚、窗框截面及固定U，图示不替代原窗深化图。']),
 'D06':('桌面 / 窗台 / 窗边座协调',15,['原标窗台600[P]；桌高750、板厚25均D。','桌面高于窗台150，图中明确表示该冲突。',
    '窗边座高500[D]，其中坐垫70[D]。','桌板支承/角码固定到可靠基层，规格按跨距另核。','窗扇开启范围U；取得现场数据前不作为安装定案。']),
 'D07':('窗帘槽 / 轨道 / 吊顶端部',5,['槽净宽180、建议预留深150均D。','顶面板12.5+12.5[D]，需完整龙骨与吊挂体系。',
    '轨道/电机按产品实物复核，保留检修可达性。','原顶、梁底及H未确认；节点不确定房间吊顶标高。']),
 'D08':('层板 / 明装灯带型材 / 走线',2,['承载层板18[D]连续保留。','改为板底明装10×8[D]型材预留，不切掉10深承载截面。',
    '型材需先选型，扩散罩及散热空间按厂家确认。','走线进入侧板背部；驱动置于可检修位置。','大跨层板的支承和荷载需单独复核。']),
 'D09':('踢脚端头 / 门套 / 墙角',5,['踢脚高60、厚12均D，端头收于门套边。','门套板12[D]、框边3[D]控制缝。',
    '门扇厚与门框截面U，平剖仅表达收边关系。','地面与墙面完成厚度待核；门缝、开启及密封按成品门系统。'])}

def node_geometry(v,num):
 if num=='D01':
  v.rect(-35,-35,710,35,'A-WALL','section')
  v.rect(0,80,599,18,'A-OUTLINE','section');v.rect(0,98,9,180,'A-DETAIL','section')
  v.rect(602,82,18,196,'A-OUTLINE','section');v.rect(542,3,18,77,'A-DETAIL','section')
  for xx in [90,430]:
   v.rect(xx,25,24,55,'A-DETAIL');v.rect(xx-10,0,44,8,'A-SYMBOL')
   v.line((xx+8,8),(xx+8,45),'A-SYMBOL');v.line((xx+16,8),(xx+16,45),'A-SYMBOL')
  v.dx(542,602,-75,status='D',source='踢脚退后建议60');v.dy(-70,0,80,status='D')
  v.dy(690,80,98,base=620,status='D');v.tag(120,130,'M02')
  v.leader((442,45),(180,245),'调节脚 / 型号及载荷待柜厂核')
 elif num=='D02':
  v.rect(0,-120,599,18,'A-OUTLINE','section');v.rect(602,-150,18,48,'A-OUTLINE','section')
  v.rect(0,-102,9,180,'A-DETAIL','section');v.rect(602,-102,18,180,'A-DETAIL','section')
  v.line((-20,160),(650,160),'A-PENDING');v.zig(60,160);v.txt(100,190,'原顶/完成顶位置U')
  v.rect(602,78,12,55,'A-DETAIL','section')
  v.poly([(570,-102),(570,-75),(590,-75),(590,-78),(573,-78),(573,-102)],'A-SYMBOL')
  m.add_circle(v.p((582,-78)),3,dxfattribs={'layer':'A-SYMBOL'})
  v.dy(700,-120,-102,base=620,status='D')
  v.leader((608,110),(220,80),'可调封板；高度按H与柜顶实测扣算')
 elif num=='D03':
  v.rect(0,0,18,120,'A-OUTLINE','section')
  v.rect(0,-21,100,18,'A-OUTLINE','section');v.rect(103,-21,100,18,'A-OUTLINE','section')
  v.poly([(60,-3),(60,10),(18,25),(18,45)],'A-SYMBOL')
  m.add_circle(v.p((70,-10)),5,dxfattribs={'layer':'A-SYMBOL'})
  v.dx(100,103,55,-3,status='D');v.dy(-30,-21,-3,status='D');v.dx(0,18,145,120,status='D')
  v.tag(110,100,'M02')
 elif num=='D04':
  v.rect(0,0,260,55,'A-WALL','section');v.zig(240,45)
  v.rect(0,-12,150,12,'A-DETAIL','section');v.rect(0,-22,150,10,'A-DETAIL','fabric')
  v.rect(153,-22,18,22,'A-OUTLINE','wood');v.rect(171,-18,89,18,'A-DETAIL','wood')
  v.dy(-30,-22,-12,status='D');v.dy(290,-12,0,base=260,status='D')
  v.dx(150,153,-50,-22,status='D')
  v.tag(40,-45,'M03');v.tag(190,-42,'M02')
  v.line((40,-10),(40,20),'A-SYMBOL');m.add_circle(v.p((40,-7)),2,dxfattribs={'layer':'A-SYMBOL'})
 elif num=='D05':
  v.poly([(0,0),(120,0),(120,100),(0,100)],'A-WALL')
  fill(m,[v.p(p) for p in [(0,0),(120,0),(120,100),(0,100)]],'section')
  v.rect(0,-12,132,12,'A-OUTLINE','wood');v.rect(120,0,12,95,'A-OUTLINE','wood')
  v.rect(135,80,40,40,'A-GLASS');v.line((175,100),(250,100),'A-GLASS')
  v.line((132,80),(135,83),'A-DETAIL')
  v.dx(132,135,45,80,status='D');v.dy(-25,-12,0,status='D')
  v.tag(15,-28,'M02');v.tag(180,125,'M05')
 elif num=='D06':
  v.line((-50,0),(1150,0),'A-FLOOR')
  v.rect(0,0,70,600,'A-WALL','section');v.rect(0,600,55,40,'A-GLASS')
  v.line((28,640),(28,1050),'A-GLASS');v.zig(28,990)
  v.line((-60,600),(1150,600),'A-HIDDEN',ltscale=4)
  v.rect(90,725,510,25,'A-OUTLINE','section')
  v.rect(535,0,25,725,'A-DETAIL','section')
  v.poly([(90,725),(90,650),(150,650)],'A-SYMBOL')
  v.rect(700,0,420,430,'A-OUTLINE');v.rect(710,430,400,70,'A-DETAIL','fabric')
  v.dy(-180,0,600,status='P',source='原窗标LD600')
  v.dy(1240,0,750,base=1120,status='D');v.dy(655,600,750,base=600,status='D')
  v.dy(1150,430,500,base=1120,status='D');v.txt(120,880,'150高差未解决；开扇U')
  v.txt(700,550,'窗边座 D')
 elif num=='D07':
  v.rect(0,0,100,210,'A-WALL','section');v.zig(50,190)
  v.rect(100,0,18,150,'A-DETAIL','section');v.rect(298,0,18,150,'A-DETAIL','section')
  v.rect(316,0,280,12.5,'A-DETAIL','gypsum');v.rect(316,12.5,280,12.5,'A-DETAIL','gypsum')
  v.rect(335,25,35,35,'A-SYMBOL');v.line((350,60),(350,210),'A-SYMBOL')
  v.rect(145,90,95,25,'A-DETAIL');v.line((165,90),(165,20),'A-DETAIL');v.line((215,90),(215,20),'A-DETAIL')
  v.dx(118,298,-55,status='D');v.dy(650,0,150,base=596,status='D')
  v.txt(110,220,'顶内连接及梁底U，需完整吊挂体系')
 elif num=='D08':
  v.rect(0,0,210,18,'A-OUTLINE','section')
  v.poly([(40,0),(40,-8),(50,-8),(50,0)],'A-LIGHT')
  v.line((41,-7),(49,-7),'A-GLASS')
  v.line((46,0),(46,5),'A-HIDDEN');v.line((46,5),(0,5),'A-HIDDEN')
  v.line((0,5),(-25,5),'A-HIDDEN')
  v.rect(-25,-20,12,60,'A-WALL','section')
  v.dy(240,0,18,base=210,status='D');v.dx(40,50,-35,-8,status='D')
  v.dy(75,-8,0,base=50,status='D')
  v.tag(100,45,'M02')
 elif num=='D09':
  v.rect(0,0,150,75,'A-WALL','section')
  v.rect(0,-12,110,12,'A-DETAIL','wood');v.rect(113,-15,12,90,'A-DETAIL','wood')
  v.poly([(125,35),(155,35),(155,65)],'A-OUTLINE')
  v.dx(110,113,-45,-12,status='D');v.dy(-25,-12,0,status='D')
  v.txt(10,105,'门套平剖意向 / 截面U')
  # Separate elevation fragment of the skirting termination.
  v.rect(0,-180,100,60,'A-OUTLINE','wood');v.rect(103,-180,12,100,'A-DETAIL')
  v.line((-10,-180),(150,-180),'A-FLOOR')
  v.dy(-25,-180,-120,status='D');v.txt(0,-210,'踢脚端头收于门套')

numbers=list(NODE_INFO)
for j in range(5):
 code=f'ND-{j+1:02}';ps=sheet(code,'节点深化 / '+(' · '.join(numbers[j*2:j*2+2])),
          '所有未标P的节点尺寸与连接构造均为D；原基层及未确认条件标U','各图注明')
 for k,num in enumerate(numbers[j*2:j*2+2]):
  name,sc,notes=NODE_INFO[num];top=250-k*112
  txt(ps,20,top,num+'  '+name,3.5,'S-TEXT');txt(ps,20,top-7,'比例 1:'+str(sc)+' / 模型1:1 mm',2.5,'S-TEXT')
  v=View(280000+(j*2+k)*5000,0,sc,code);node_geometry(v,num)
  # Coordinate-specific view centre avoids fitting or distorting details.
  centres={'D01':(305,110),'D02':(300,10),'D03':(85,62),'D04':(130,5),'D05':(110,50),
           'D06':(530,500),'D07':(300,75),'D08':(105,10),'D09':(65,-55)}
  viewport(ps,v,(110,top-57),(180,95),centres[num],sc)
  lines(ps,213,top-16,notes,width=68,h=2.7,leading=4.7)
  if k==0:line(ps,(16,top-104),(404,top-104),'S-FRAME')
 if j==4:
  txt(ps,215,125,'接口检查重点',3.5,'S-TEXT')
  lines(ps,215,114,['柜体必须核对门扇、抽屉、窗扇和检修空间。','窗套、门套与踢脚应连续收口并区分原有与新增。',
    '没有完整现场数据的接口保留U；文件审计通过不等于节点已具备施工条件。'],width=65,h=2.7,leading=5)
