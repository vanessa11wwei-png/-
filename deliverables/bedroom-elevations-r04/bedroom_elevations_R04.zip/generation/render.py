from pathlib import Path
import argparse,json
import ezdxf,fitz
from ezdxf.addons.drawing import RenderContext,Frontend,layout,config,pymupdf
from ezdxf.math import BoundingBox2d

# ezdxf 1.4.4 truncates page dimensions to integer PDF points. Keep fractional
# points so A3 size and the plotted scale remain exact instead of shrinking 0.05%.
pymupdf.get_coordinate_output_space=lambda p:max(p.width_in_mm,p.height_in_mm)*72/25.4
class ExactRender(pymupdf.PyMuPdfRenderBackend):
 def __init__(self,page,settings):
  super().__init__(page,settings)
  self.doc.delete_page(0)
  self.page_width_in_pt=page.width_in_mm*72/25.4;self.page_height_in_pt=page.height_in_mm*72/25.4
  self.page=self.doc.new_page(-1,self.page_width_in_pt,self.page_height_in_pt)
  self.content_shape=self.page.new_shape()
class ExactBackend(pymupdf.PyMuPdfBackend):
 @staticmethod
 def make_backend(page,settings):return ExactRender(page,settings)

p=argparse.ArgumentParser();p.add_argument('--sample',action='store_true');p.add_argument('--input',type=Path)
a=p.parse_args();root=Path('/workspace/bedroom-elevations-r04');work=Path('/workspace/cad-review-r04/render');work.mkdir(exist_ok=True)
d=ezdxf.readfile(a.input or root/'bedroom_elevations_R04.dxf')
names=[s['layout'] for s in json.loads((root/'sheet_index_R04.json').read_text())]
if a.sample:names=['EL-01','EL-09','EL-11','EL-12','JB-01','ND-01','ND-03','ND-04']
pdf=fitz.open();cfg=config.Configuration(background_policy=config.BackgroundPolicy.WHITE,
   color_policy=config.ColorPolicy.MONOCHROME,lineweight_scaling=1,min_lineweight=.05)
page=layout.Page(420,297,layout.Units.mm);settings=layout.Settings(fit_page=False,scale=1,output_coordinate_space=1000000)
for name in names:
 ctx=RenderContext(d);backend=ExactBackend();Frontend(ctx,backend,config=cfg).draw_layout(d.layouts.get(name),finalize=True)
 data=backend.get_pdf_bytes(page,settings=settings,render_box=BoundingBox2d([(0,0),(420,297)]))
 one=fitz.open(stream=data,filetype='pdf');pdf.insert_pdf(one)
 img=one[0].get_pixmap(matrix=fitz.Matrix(1.4,1.4),alpha=False);img.save(str(work/(name+'.png')))
 print('RENDER',name,flush=True)
if not a.sample:
 pdf.set_metadata({'title':'西湖豪庭 全部卧室立面深化 R04','subject':'P原图/I意向/D建议/U待确认；深化审阅稿','author':'CAD drafting'})
 index=json.loads((root/'sheet_index_R04.json').read_text())
 pdf.set_toc([[1,s['code']+' '+s['title'],i+1] for i,s in enumerate(index)])
 pdf.save(root/'bedroom_elevations_R04.pdf',garbage=4,deflate=True)
 print('PDF PAGES',len(pdf),flush=True)
