from pathlib import Path
from collections import Counter
import math,json,hashlib
import ezdxf
from ezdxf import bbox

root=Path('/workspace/bedroom-elevations-r04')
d=ezdxf.readfile(root/'bedroom_elevations_R04.dxf');a=d.audit()
assert not a.errors and not a.fixes
records=json.loads((root/'dimension_records_R04.json').read_text())
sheets=json.loads((root/'sheet_index_R04.json').read_text())
assert len(sheets)==27 and len({s['code'] for s in sheets})==27
assert len(records)==165
native=[]
for r in records:
 e=d.entitydb[r['handle']];assert e.dxftype()=='DIMENSION'
 value=e.get_measurement();assert math.isclose(value,r['value'],abs_tol=1e-6)
 assert e.dxf.text in ['','<>']
 assert e.dxf.geometry in d.blocks
 shown=[t.plain_text() if t.dxftype()=='MTEXT' else t.dxf.text for t in d.blocks[e.dxf.geometry].query('TEXT MTEXT')]
 wanted=str(round(value))+('[D]' if r['status']=='D' else '')
 assert shown==[wanted],(r,shown,wanted)
 native.append({'handle':r['handle'],'value':value,'shown':shown[0],'status':r['status']})

for code in ['EL-'+str(i).zfill(2) for i in range(1,17)]:assert code in d.layouts
nodes={a['detail'] for a in json.loads((root/'detail_references_R04.json').read_text())}
assert nodes<=set('D'+str(i).zfill(2) for i in range(1,10))
counts=Counter(e.dxftype() for e in d.modelspace())
assert counts['DIMENSION']==165 and counts['HATCH']>=200 and counts['INSERT']>40
assert sum(len(e.attribs) for e in d.modelspace().query('INSERT'))>=40
for c in json.loads((root/'component_schedule_R04.json').read_text()):
 if 'clear_widths_D' in c:
  assert math.isclose(sum(c['clear_widths_D'])+c['side_and_divider_boards_D']*c['board_D'],c['outer_P'],abs_tol=.001)
 if 'module_centerlines_D' in c:assert c['module_centerlines_D'][-1]==c['outer_P']
 if 'width_P' in c and c.get('kind') in ['女孩房衣柜','男孩房衣柜']:
  assert sum(c['modules_D'])==c['width_P']

# Paper text and graphic annotations must be within the actual page/viewport.
cache=bbox.Cache();out=[];clipped=[];viewports=[]
for s in sheets:
 ps=d.layouts.get(s['layout'])
 for e in ps.query('TEXT MTEXT'):
  b=bbox.extents([e],cache=cache)
  if b.has_data and (b.extmin.x<11 or b.extmax.x>409 or b.extmin.y<10 or b.extmax.y>287):
   out.append({'sheet':s['code'],'text':e.dxf.get('text',''),'bounds':[b.extmin.x,b.extmin.y,b.extmax.x,b.extmax.y]})
 for vp in ps.query('VIEWPORT'):
  if vp.dxf.id<=1:continue
  assert vp.dxf.flags&16384
  scale=vp.dxf.view_height/vp.dxf.height
  viewports.append({'sheet':s['code'],'scale':scale,'locked':True})
  if s['code']=='GE-02':continue # source index intentionally crops neighbouring geometry
  c=vp.dxf.view_center_point;x0=c.x-vp.dxf.width*scale/2;x1=c.x+vp.dxf.width*scale/2
  y0=c.y-vp.dxf.view_height/2;y1=c.y+vp.dxf.view_height/2
  for e in d.modelspace():
   b=bbox.extents([e],cache=cache)
   if not b.has_data:continue
   if b.extmax.x<x0 or b.extmin.x>x1 or b.extmax.y<y0 or b.extmin.y>y1:continue
   if b.extmin.x<x0-.5 or b.extmax.x>x1+.5 or b.extmin.y<y0-.5 or b.extmax.y>y1+.5:
    clipped.append({'sheet':s['code'],'handle':e.dxf.handle,'type':e.dxftype(),
                    'text':e.dxf.get('text','') if e.dxftype() in ['TEXT','MTEXT'] else '',
                    'entity_bounds':[b.extmin.x,b.extmin.y,b.extmax.x,b.extmax.y],
                    'view_bounds':[x0,y0,x1,y1]})

src=Path('/workspace/attachments/e441ad26-1eb4-492d-abaf-8fcf28c8dbea/西湖豪庭2#2单元603_recover.dxf')
sha=hashlib.sha256(src.read_bytes()).hexdigest();assert sha=='5814e47cfc177c85b6740f29fc205c8a5d4ab04ba18f6a482a02accccfb1c981'
source=ezdxf.readfile(src)
features={}
for name,h in {'girl_wardrobe':'91CE','girl_combined_window_furniture':'90CA','master_desk':'9156',
               'boy_wardrobe':'90EB','boy_toy':'913D','secondary_thin_cabinet':'9AD2',
               'girl_head_unit':'90BE','girl_east_door_leaf':'90DD'}.items():
 e=source.entitydb[h];b=bbox.extents([e]);features[name]={'handle':h,'min':list(b.extmin),'max':list(b.extmax),
                                                       'width':b.size.x,'depth':b.size.y}
assert math.isclose(features['girl_wardrobe']['width'],2565,abs_tol=.01)
assert math.isclose(features['girl_combined_window_furniture']['depth'],2380,abs_tol=.01)
assert math.isclose(features['master_desk']['depth'],550,abs_tol=.01)
assert math.isclose(56466.75421125877-features['master_desk']['max'][1],50,abs_tol=.01)
assert math.isclose(features['boy_wardrobe']['depth'],1720,abs_tol=.01)
assert math.isclose(features['boy_toy']['depth'],200,abs_tol=.01)
assert math.isclose(45603.07005867005-features['girl_head_unit']['max'][0],1180,abs_tol=.01)
assert not any(r['value'] in [1650] for r in records if r['sheet']=='EL-12')

result={'status':'passed' if not out and not clipped else 'needs_layout_correction',
 'sheets':27,'elevations':16,'cabinet_sheets':3,'construction_nodes':9,'native_dimension_checks':len(native),
 'model_entities':dict(counts),'audit_errors':0,'audit_fixes':0,'source_sha256':sha,
 'paper_text_outside':out,'clipped_view_entities':clipped,'viewports':viewports,
 'source_geometry_rechecks':features,'dimensions':native,
 'unresolved':['完成吊顶净高','门窗竖向及分格U','桌窗150高差','门套邻柜20余量','玩具柜深200与篮筐选型','厂家固定/承载/样板签审']}
(root/'checks_R04.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['dimensions','viewports','source_geometry_rechecks']},ensure_ascii=False))
