from pathlib import Path
from collections import Counter
import json,math,hashlib,shutil
import ezdxf
from ezdxf.lldxf.encoding import decode_dxf_unicode

root=Path('/workspace/bedroom-elevations-r04');work=Path('/workspace/cad-review-r04')
a=ezdxf.readfile(root/'bedroom_elevations_R04.dxf')
b=ezdxf.readfile(work/'oda-back/bedroom_elevations_R04.dxf')
for d in [a,b]:
 au=d.audit();assert not au.errors and not au.fixes
assert a.units==b.units==4
assert set(a.layouts.names())==set(b.layouts.names())
for name in a.layouts.names():
 assert Counter(e.dxftype() for e in a.layouts.get(name))==Counter(e.dxftype() for e in b.layouts.get(name)),name

def points(e):
 t=e.dxftype()
 if t=='LINE':return [tuple(e.dxf.start),tuple(e.dxf.end)]
 if t=='LWPOLYLINE':return list(e.get_points())
 if t=='CIRCLE':return [tuple(e.dxf.center),(e.dxf.radius,)]
 if t=='TEXT':return [tuple(e.dxf.insert),(e.dxf.height,e.dxf.rotation)]
 if t=='INSERT':return [tuple(e.dxf.insert),(e.dxf.rotation,)]
 if t=='DIMENSION':return [tuple(e.dxf.defpoint),tuple(e.dxf.defpoint2),tuple(e.dxf.defpoint3),(e.get_measurement(),)]
 if t=='WIPEOUT':return [tuple(e.dxf.insert),tuple(e.dxf.u_pixel),tuple(e.dxf.v_pixel)]+list(e.boundary_path)
 if t=='HATCH':
  p=[]
  for path in e.paths:
   assert hasattr(path,'vertices');p+=list(path.vertices)
  return p
 return []

checked=Counter()
normalizations=[]
def same_value(x,y):
 if isinstance(x,(int,float)) and isinstance(y,(int,float)):return math.isclose(x,y,abs_tol=1e-8)
 if hasattr(x,'__iter__') and not isinstance(x,str):return all(same_value(i,j) for i,j in zip(x,y))
 return x==y
for name in a.layouts.names():
 for e in a.layouts.get(name):
  other=b.entitydb.get(e.dxf.handle);assert other is not None and other.dxftype()==e.dxftype()
  if e.dxftype()=='VIEWPORT' and e.dxf.id==1 and e.dxf.layer=='VIEWPORTS' and other.dxf.layer=='0':
   normalizations.append({'layout':name,'object':'overall paper viewport','change':'VIEWPORTS layer -> 0 (non-graphic layout metadata)'})
  else:assert e.dxf.layer==other.dxf.layer
  assert e.dxf.color==other.dxf.color
  if e.dxftype()=='TEXT':assert decode_dxf_unicode(e.dxf.text)==decode_dxf_unicode(other.dxf.text)
  if e.dxftype()=='DIMENSION':
   aa=[t.plain_text() for t in a.blocks[e.dxf.geometry].query('MTEXT')]
   bb=[t.plain_text() for t in b.blocks[other.dxf.geometry].query('MTEXT')]
   assert aa==bb and e.dxf.text==other.dxf.text
  if e.dxftype()=='INSERT':
   assert e.dxf.name==other.dxf.name
   assert [(t.dxf.tag,t.dxf.text) for t in e.attribs]==[(t.dxf.tag,t.dxf.text) for t in other.attribs]
  if e.dxftype()=='HATCH':
   for attr in ['pattern_name','pattern_scale','pattern_angle','solid_fill']:
    assert e.dxf.get(attr)==other.dxf.get(attr),(attr,e.dxf.handle)
  if e.dxftype()=='VIEWPORT':
   for attr in ['width','height','view_height','view_center_point','center','flags']:
    assert same_value(e.dxf.get(attr),other.dxf.get(attr)),(name,attr,e.dxf.get(attr),other.dxf.get(attr))
  p,q=points(e),points(other);assert len(p)==len(q),(e,p,q)
  for x,y in zip(p,q):
   assert len(x)==len(y)
   assert all(math.isclose(float(xx),float(yy),abs_tol=1e-5) for xx,yy in zip(x,y)),(e.dxftype(),e.dxf.handle,x,y)
  checked[e.dxftype()]+=1

assert [e.dxf.handle for e in a.modelspace().entities_in_redraw_order()]==[e.dxf.handle for e in b.modelspace().entities_in_redraw_order()]
for layer in a.layers:
 name=layer.dxf.name
 assert layer.dxf.lineweight==b.layers.get(name).dxf.lineweight
 assert layer.dxf.plot==b.layers.get(name).dxf.plot
assert b.styles.get('CN').dxf.font=='NotoSansCJK-Regular.ttc'
p=work/'oda-dwg/bedroom_elevations_R04.dwg';assert p.read_bytes()[:6]==b'AC1027'
shutil.copy2(p,root/p.name)
report={'status':'passed','converter':'ODA File Converter 27.9.0.0','dwg_version':'AC1027 / AutoCAD 2013',
 'units':'mm','layouts':27,'native_dimensions_model':len(b.modelspace().query('DIMENSION')),
 'native_hatches_model':len(b.modelspace().query('HATCH')),'native_wipeouts_model':len(b.modelspace().query('WIPEOUT')),
 'material_leaders_paper':sum(len(b.layouts.get(n).query('LEADER')) for n in b.layouts.names() if n!='Model'),
 'checked_objects_including_paperspace':dict(checked),'audit_errors':0,'audit_fixes':0,
 'geometry_and_text_match':True,'dimension_display_values_match':True,'mask_boundaries_match':True,
 'draw_order_match':True,'viewport_parameters_match':True,'layer_lineweights_match':True,
 'native_hatch_patterns_match':True,'attributes_match':True,'DWG_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
 'known_metadata_normalizations':normalizations,'manual_AutoCAD_open_or_plot':False}
(root/'DWG_roundtrip_R04.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False))
