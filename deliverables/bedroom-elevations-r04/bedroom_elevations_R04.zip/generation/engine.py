from __future__ import annotations
from pathlib import Path
import math,json
import ezdxf
from ezdxf import units
from ezdxf.enums import TextEntityAlignment
from ezdxf.math import Vec2
from ezdxf.fonts import fonts

OUT=Path('/workspace/bedroom-elevations-r04');OUT.mkdir(exist_ok=True)
FONT='NotoSansCJK-Regular.ttc'
LAYERS={'A-WALL':50,'A-OUTLINE':35,'A-DETAIL':18,'A-HATCH':9,'A-DIM':13,
        'A-TEXT':13,'A-MATERIAL':13,'A-SYMBOL':18,'A-OPEN':9,'A-HIDDEN':9,
        'A-PENDING':13,'A-FLOOR':50,'A-GLASS':18,'A-LIGHT':18,'A-RECESS':13,'A-MASK':0,'S-FRAME':25,
        'S-VPORT':0,'S-TEXT':13}
doc=ezdxf.new('R2013',setup=True);doc.units=units.MM
doc.header['$MEASUREMENT']=1;doc.header['$LWDISPLAY']=True
doc.styles.new('CN',dxfattribs={'font':FONT,'width':1})
for layer,weight in LAYERS.items():
 doc.layers.new(layer,dxfattribs={'lineweight':weight,'color':8 if layer in ['A-HATCH','A-HIDDEN','A-PENDING','A-RECESS'] else 7,
                                'linetype':'DASHED' if layer in ['A-OPEN','A-HIDDEN','A-PENDING'] else 'Continuous',
                                'plot':0 if layer=='S-VPORT' else 1})
m=doc.modelspace();SHEETS=[];DIMS=[];REFS=[];COMPONENTS=[];TEXTS=[]
_font=fonts.make_font(FONT,1)

def line(space,a,b,layer='A-DETAIL',**attrs):
 if math.dist(a,b)>1e-8:return space.add_line(a,b,dxfattribs={'layer':layer,**attrs})

def poly(space,points,layer='A-DETAIL',closed=False):
 return space.add_lwpolyline(points,close=closed,dxfattribs={'layer':layer})

def rect(space,x,y,w,h,layer='A-DETAIL',pattern=None):
 assert w>0 and h>0,(w,h)
 points=[(x,y),(x+w,y),(x+w,y+h),(x,y+h)]
 if pattern:fill(space,points,pattern)
 return poly(space,points,layer,True)

def fill(space,points,kind='section'):
 e=space.add_hatch(dxfattribs={'layer':'A-RECESS' if kind=='shadow' else 'A-HATCH' if kind!='solid' else 'A-FLOOR'})
 e.paths.add_polyline_path(points,is_closed=True)
 if kind=='solid':e.set_solid_fill(color=7)
 elif kind=='shadow':e.set_solid_fill(color=9)
 else:
  pattern,scale,angle={'section':('ANSI31',1.5,0),'fabric':('ANSI37',18,0),
                       'wood':('ANSI31',30,45),'paint':('DOTS',20,0),
                       'gypsum':('ANSI31',1,90),'glass':('ANSI31',45,0)}[kind]
  e.set_pattern_fill(pattern,scale=scale,angle=angle)
 return e

def txt(space,x,y,value,h=60,layer='A-TEXT',rotation=0,align=None):
 e=space.add_text(str(value),dxfattribs={'height':h,'style':'CN','layer':layer,'rotation':rotation})
 e.set_placement((x,y),align=align or TextEntityAlignment.LEFT)
 TEXTS.append({'space':space.name,'text':str(value),'x':x,'y':y,'height':h})
 return e

def wrap(value,width):
 # TrueType CAD height uses cap height, not the CJK em square. Use actual
 # advance widths; a character-count wrap can run past the right sheet edge.
 chunks=[];s='';n=0
 for c in value:
  a=_font.text_width(c)
  if n+a>width and s:chunks.append(s);s='';n=0
  s+=c;n+=a
 if s:chunks.append(s)
 return chunks

def lines(space,x,y,items,h=2.5,leading=4,width=50,layer='S-TEXT'):
 for item in items:
  for chunk in wrap(item,width):txt(space,x,y,chunk,h,layer);y-=leading
  y-=1
 return y

def dim(space,p1,p2,base,scale=25,angle=0,status='P',source='',sheet='',component=''):
 ov={'dimtxt':2.5,'dimasz':2,'dimtsz':.8,'dimexo':1,'dimexe':1.5,'dimgap':1,
     'dimscale':scale,'dimlfac':1,'dimdec':0,'dimzin':8,'dimpost':'<>[D]' if status=='D' else '', 'dimtad':1,
     'dimclrd':0,'dimclre':0,'dimclrt':0,'dimtxsty':'CN'}
 e=space.add_linear_dim(base=base,p1=p1,p2=p2,angle=angle,dimstyle='EZDXF',override=ov,
                        dxfattribs={'layer':'A-DIM'})
 e.render()
 DIMS.append({'handle':e.dimension.dxf.handle,'value':round(e.dimension.get_measurement(),6),
              'p1':list(p1),'p2':list(p2),'angle':angle,'status':status,'source':source,
              'sheet':sheet,'component':component})
 return e.dimension

def leader(space,point,end,value,scale=25):
 knee=(end[0]-100,end[1]);space.add_leader([point,knee,end],
   override={'dimscale':scale,'dimasz':1.4},dxfattribs={'layer':'A-SYMBOL','dimstyle':'EZDXF'})
 txt(space,end[0]+30,end[1]+20,value,2.5*scale)

def tag(space,x,y,value,scale=25,layer='A-MATERIAL'):
 w=max(4,len(value)*1.6)*scale
 rect(space,x,y,w,4*scale,layer);txt(space,x+w/2,y+.7*scale,value,2.5*scale,layer,align=TextEntityAlignment.CENTER)

def detail(space,x,y,number,scale=25,sheet=''):
 radius=3.5*scale
 space.add_circle((x,y),radius,dxfattribs={'layer':'A-SYMBOL'})
 txt(space,x,y-1*scale,number,2.3*scale,'A-SYMBOL',align=TextEntityAlignment.CENTER)
 REFS.append({'sheet':sheet,'detail':number})

def zig(space,x,y,scale=25):
 poly(space,[(x-2*scale,y-2*scale),(x+2*scale,y),(x-2*scale,y+2*scale),(x+2*scale,y+4*scale)],'A-PENDING')

def init_blocks():
 b=doc.blocks.new('HW-HANDLE')
 rect(b,-6,-80,12,160,'0');b.add_circle((0,0),9)
 b.add_attdef('STATUS',(18,0),text='D',height=35,dxfattribs={'style':'CN'})
 b=doc.blocks.new('LEVEL-FFL')
 poly(b,[(0,0),(65,65),(130,0)],'0',True)
 line(b,(0,0),(210,0),'0');b.add_attdef('VALUE',(145,30),text='±0.000',height=60,dxfattribs={'style':'CN'})
 b=doc.blocks.new('HW-HINGE-D')
 rect(b,-8,-25,16,50,'0');line(b,(-18,0),(18,0),'0')

init_blocks()

class View:
 def __init__(self,ox=0,oy=0,scale=25,sheet=''):
  self.x=ox;self.y=oy;self.s=scale;self.sheet=sheet
 def p(self,p):return (self.x+p[0],self.y+p[1])
 def line(self,a,b,layer='A-DETAIL',**attrs):return line(m,self.p(a),self.p(b),layer,**attrs)
 def poly(self,pts,layer='A-DETAIL',closed=False):return poly(m,[self.p(p) for p in pts],layer,closed)
 def mask(self,x,y,w,h):
  return m.add_wipeout([self.p(p) for p in [(x,y),(x+w,y),(x+w,y+h),(x,y+h)]],dxfattribs={'layer':'A-MASK'})
 def rect(self,x,y,w,h,layer='A-DETAIL',pattern=None,opaque=False):
  if opaque:self.mask(x,y,w,h)
  return rect(m,self.x+x,self.y+y,w,h,layer,pattern)
 def txt(self,x,y,value,h=None,layer='A-TEXT',rot=0):return txt(m,self.x+x,self.y+y,value,h or 2.5*self.s,layer,rot)
 def tag(self,x,y,value):tag(m,self.x+x,self.y+y,value,self.s)
 def detail(self,x,y,number):detail(m,self.x+x,self.y+y,number,self.s,self.sheet)
 def dx(self,a,b,y,base=0,status='P',source='',component=''):
  return dim(m,self.p((a,base)),self.p((b,base)),self.p((0,y)),self.s,0,status,source,self.sheet,component)
 def dy(self,x,a,b,base=0,status='D',source='',component=''):
  return dim(m,self.p((base,a)),self.p((base,b)),self.p((x,0)),self.s,90,status,source,self.sheet,component)
 def leader(self,p,end,value):return leader(m,self.p(p),self.p(end),value,self.s)
 def zig(self,x,y):zig(m,self.x+x,self.y+y,self.s)
 def handle(self,x,y):
  ins=m.add_blockref('HW-HANDLE',self.p((x,y)),dxfattribs={'layer':'A-SYMBOL'})
  ins.add_auto_attribs({'STATUS':'D'})
 def level(self,x,y,value='±0.000'):
  ins=m.add_blockref('LEVEL-FFL',self.p((x,y)),dxfattribs={'layer':'A-SYMBOL'})
  ins.add_auto_attribs({'VALUE':value})

def sheet(code,title,subtitle='',scale='详见各图'):
 if not SHEETS:
  doc.layouts.rename('Layout1',code);ps=doc.layouts.get(code)
 else:ps=doc.layouts.new(code)
 ps.page_setup(size=(420,297),margins=(0,0,0,0),units='mm')
 rect(ps,10,10,400,277,'S-FRAME');line(ps,(10,264),(410,264),'S-FRAME')
 txt(ps,17,275,title,4.6,'S-TEXT');txt(ps,17,267,subtitle,2.5,'S-TEXT')
 line(ps,(10,23),(410,23),'S-FRAME')
 for x in [192,274,332,372]:line(ps,(x,10),(x,23),'S-FRAME')
 for x,t in [(15,'西湖豪庭 2#2单元603'),(197,'卧室深化 / R04'),(279,code),(337,scale),(377,'待签审')]:txt(ps,x,14,t,2.7,'S-TEXT')
 SHEETS.append({'code':code,'title':title,'layout':code,'scale':scale})
 return ps

def viewport(ps,view,center,size,model_center,scale):
 status=2+len([v for v in ps.query('VIEWPORT') if v.dxf.id>1])
 vp=ps.add_viewport(center=center,size=size,view_center_point=view.p(model_center),view_height=size[1]*scale,
                     status=status,dxfattribs={'layer':'S-VPORT'})
 vp.dxf.flags|=16384
 return vp

def grid(ps,x,y,widths,rows,h=2.5,row_h=10):
 total=sum(widths);bottom=y-row_h*len(rows)
 rect(ps,x,bottom,total,row_h*len(rows),'S-FRAME')
 for j in range(1,len(rows)):line(ps,(x,y-j*row_h),(x+total,y-j*row_h),'S-FRAME')
 xx=x
 for w in widths[:-1]:xx+=w;line(ps,(xx,bottom),(xx,y),'S-FRAME')
 for j,row in enumerate(rows):
  xx=x
  for w,t in zip(widths,row):
   ss=wrap(str(t),max(3,(w-4)/h))
   assert len(ss)<=max(1,int((row_h-2)/3.5)),(t,ss,w,row_h)
   for k,s in enumerate(ss):txt(ps,xx+2,y-j*row_h-4-k*3.5,s,h,'S-TEXT')
   xx+=w

def frame(v,w):
 v.line((-90,0),(w+90,0),'A-FLOOR');v.rect(-90,-55,w+180,55,'A-FLOOR','solid')
 for xx in [-70,w]:
  v.rect(xx,0,70,2500,'A-WALL','section');v.zig(xx+35,2470)
 v.level(-330,0)
 # No guessed ceiling datum is drawn or dimensioned.
 v.dx(0,w,-490,status='P',source='原平面边界/尺寸链',component='wall_overall')
 v.txt(0,-650,'主图尺寸：P为原图，D为设计建议；门窗竖向未确认项见右栏',2.5*v.s)

def cabinet(v,x,w,n=4,h=2400,label='衣柜',depth=620,source='',upper=True):
 b=18;kick=80;u=420 if upper else 0
 v.mask(x,0,w,h);v.rect(x,0,w,h,'A-OUTLINE');v.rect(x,kick,w,h-kick,'A-DETAIL')
 if upper:v.line((x,h-u),(x+w,h-u),'A-DETAIL')
 modules=[round(w*(i+1)/n)-round(w*i/n) for i in range(n)]
 start=x
 for i,mw in enumerate(modules):
  left=start+1.5;ww=mw-3
  v.rect(left,kick+1.5,ww,h-u-kick-3,'A-OUTLINE','paint')
  if upper:v.rect(left,h-u+1.5,ww,u-3,'A-DETAIL')
  hingeleft=i%2==0;hx=left if hingeleft else left+ww;ex=left+ww if hingeleft else left
  v.line((ex,kick+35),(hx,(h-u+kick)/2),'A-OPEN',ltscale=8)
  v.line((hx,(h-u+kick)/2),(ex,h-u-35),'A-OPEN',ltscale=8)
  v.handle(left+ww-45 if hingeleft else left+45,1050)
  v.dx(start,start+mw,h+200,h,status='D',source='模块设计，非下料尺寸',component=label+'_module')
  start+=mw
 v.dy(x+w+170,0,h,base=x+w,status='D',source='柜高设计建议')
 v.detail(x+w-100,180,'D01');v.detail(x+w-100,h-80,'D02')
 # The side edge is timber; front finish is separately coded, not all woodgrain.
 v.rect(x+1.5,kick+1.5,18,h-kick-3,'A-DETAIL','wood')
 v.tag(x+w*.35,1300,'M09')
 COMPONENTS.append({'sheet':v.sheet,'kind':label,'width_P':w,'depth_P':depth,'height_D':h,
                    'board_D':18,'gap_D':3,'kick_D':80,'modules_D':modules,'source':source,
                    'module_note':'中心线分配，不等于门板下料或内部净宽'})

def shelf(v,x,w,h=2300,tiers=5,label='开放格',source=''):
 v.mask(x,0,w,h)
 fill(m,[v.p(p) for p in [(x+18,98),(x+w-18,98),(x+w-18,h-18),(x+18,h-18)]],'shadow')
 v.rect(x,0,w,h,'A-OUTLINE');v.rect(x,0,w,80,'A-DETAIL')
 v.rect(x,80,18,h-80,'A-DETAIL','section');v.rect(x+w-18,80,18,h-80,'A-DETAIL','section')
 n=max(1,math.ceil(w/700));mw=(w-(n+1)*18)/n
 for i in range(1,n):v.rect(x+18+i*mw+(i-1)*18,80,18,h-80,'A-DETAIL','section')
 for i in range(tiers+1):
  yy=80+(h-98)*i/tiers;v.rect(x+18,yy,w-36,18,'A-DETAIL','section',opaque=True)
  if i and h>1400:v.line((x+30,yy-12),(x+w-30,yy-12),'A-LIGHT')
 # Visible contents from P60/P61/P67: books in tall open niches and shallow
 # container fronts in the toy unit. They are design-intent silhouettes only.
 step=(h-98)/tiers
 for col in range(n):
  cx=x+18+col*(mw+18)
  for row in range(tiers):
   yy=98+row*step
   if h>1400:
    if row%2:
     for j in range(4):
      bw=min(mw-80,260)-j*12
      v.rect(cx+40+j*4,yy+3+j*22,bw,18,'A-DETAIL',opaque=True)
    else:
     for j in range(4):
      xx=cx+40+j*45;hh=min(step-75,180+j*18)
      v.rect(xx,yy+4,33,hh,'A-DETAIL',opaque=True)
      v.line((xx+6,yy+25),(xx+27,yy+25),'A-DETAIL')
   else:
    hh=min(step-50,160)
    v.rect(cx+30,yy+10,mw-60,hh,'A-DETAIL',opaque=True)
    v.rect(cx+mw/2-35,yy+hh-15,70,12,'A-DETAIL')
 v.tag(x+40,h*.55,'M02');v.detail(x+w-100,h-120,'D08')
 COMPONENTS.append({'sheet':v.sheet,'kind':label,'width_P':w,'height_D':h,'modules_D':[round(mw,3)]*n,
                    'board_D':18,'clear_width_rule':f'({w}-({n}+1)*18)/{n}', 'source':source})

def bed(v,x,w,side=False,child=False):
 v.rect(x+25,100,w-50,320,'A-OUTLINE',opaque=True);v.rect(x+35,420,w-70,170,'A-DETAIL','fabric',opaque=True)
 v.line((x+60,510),(x+w-60,510),'A-DETAIL')
 if not side:
  v.rect(x,500,w,560,'A-OUTLINE','fabric',opaque=True)
  for xx in [x+65,x+w/2+20]:v.rect(xx,650,w/2-85,230,'A-DETAIL',opaque=True)
 if child:
  for xx in [x,x+w-55]:v.rect(xx,80,55,1620,'A-OUTLINE','wood')
  for delta in [0,55]:v.poly([(x,1700+delta),(x+w/2,2100+delta),(x+w,1700+delta)],'A-OUTLINE')
  # Visible design features from P60/P61/P65/P66: canopy facing, cloud crest,
  # rounded upholstered head and ladder rungs. Their fabrication sizes remain D.
  fill(m,[v.p(p) for p in [(x+80,1725),(x+w/2,2040),(x+w-80,1725)]],'fabric')
  crest=[]
  for centre,radius in [(x+w/2-90,60),(x+w/2,80),(x+w/2+90,60)]:
   for j in range(13):
    angle=math.pi-j*math.pi/12
    crest.append((centre+radius*math.cos(angle),2160+radius*math.sin(angle)))
  v.poly([(x+w/2-150,2100)]+crest+[(x+w/2+150,2100)],'A-OUTLINE')
  if not side:
   profile=[(x+90,530),(x+90,940)]
   for j in range(25):
    angle=math.pi-j*math.pi/24
    profile.append((x+w/2+(w/2-90)*math.cos(angle),940+190*math.sin(angle)))
   profile.append((x+w-90,530));v.poly(profile,'A-DETAIL')
  if side:
   for yy in range(390,1650,210):v.rect(x+55,yy,350,24,'A-DETAIL')
  v.tag(x+w/2,1750,'M04');v.txt(x+70,2240,'成品床造型 D；结构及固定由厂家确认')

def desk(v,x,w,h=750,side=False):
 v.rect(x,h-25,w,25,'A-OUTLINE','section',opaque=True)
 for xx in [x+25,x+w-50]:v.rect(xx,0,25,h-25,'A-DETAIL',opaque=True)
 if w>900 and not side:
  v.rect(x+45,510,w-90,190,'A-OUTLINE',opaque=True)
  for yy in [525,685]:v.line((x+65,yy),(x+w-65,yy),'A-DETAIL')
  v.line((x+w/2,510),(x+w/2,700),'A-DETAIL')
 v.tag(x+w/2,h+70,'M02');v.detail(x+w-90,h-110,'D06')

def window(v,x,w,known=False,inner=False):
 s=600 if not inner else 700;h=1810 if not inner else 1500
 v.rect(x,s,w,h,'A-GLASS');v.rect(x+35,s+35,w-70,h-70,'A-GLASS')
 n=4 if w>2000 else 2
 for i in range(1,n):v.rect(x+w*i/n-15,s+35,30,h-70,'A-GLASS')
 v.line((x+35,s+h*.5),(x+w-35,s+h*.5),'A-GLASS')
 for j in range(n):
  xx=x+j*w/n+70;v.line((xx,s+200),(xx+min(w/n-130,250),s+430),'A-GLASS')
 v.rect(x-20,s-22,w+40,22,'A-DETAIL')
 v.tag(x+60,s+h*.65,'M05');v.detail(x+w-80,s+130,'D05')
 if known:
  v.dy(x-180,0,s,base=x,status='P',source='原测绘窗标LD600')
  v.dy(x-180,s,s+h,base=x,status='P',source='原测绘窗高1810')
 else:
  v.zig(x,s+300);v.zig(x+w,s+300)
  v.txt(x+35,s+h+70,'窗台/窗高/分格 U，保留原窗')

def door(v,x,w):
 h=2250
 v.rect(x-40,0,w+80,h+35,'A-OUTLINE');v.rect(x,0,w,h,'A-OUTLINE','wood')
 v.line((x+25,30),(x+25,h-25),'A-DETAIL');v.handle(x+w-90,1050)
 v.zig(x,h-190);v.zig(x+w,h-190)
 v.txt(x+40,120,'HD：U',2.5*v.s,'A-PENDING')
 v.tag(x+60,1600,'M02');v.detail(x+w-70,1900,'D09')

def dimension_chain(v,points,y=-220,source='原平面尺寸/几何',status='P'):
 for a,b in zip(points,points[1:]):v.dx(a,b,y,source=source,status=status)

def notes_panel(ps,items):
 line(ps,(298,65),(298,254),'S-FRAME')
 y=248
 for title,body in items:
  txt(ps,305,y,title,3,'S-TEXT');y-=7
  y=lines(ps,305,y,body,h=2.5,leading=4,width=37);y-=5
 assert y>63,('notes overflow',y)

def bottom_info(ps,rows):
 grid(ps,18,65,[20,252],rows,h=2.5,row_h=9)

def save():
 path=OUT/'bedroom_elevations_R04.dxf';doc.saveas(path)
 for name,records in [('sheet_index',SHEETS),('dimension_records',DIMS),('detail_references',REFS),
                       ('component_schedule',COMPONENTS),('text_records',TEXTS)]:
  (OUT/(name+'_R04.json')).write_text(json.dumps(records,ensure_ascii=False,indent=2))
 return path
