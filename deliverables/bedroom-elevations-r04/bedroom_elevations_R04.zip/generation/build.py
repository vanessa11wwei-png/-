from engine import *
from ezdxf import bbox,disassemble

ROOMS=json.loads(Path('/workspace/bedroom-elevations-r02/尺寸依据.json').read_text())
SOURCE=Path('/workspace/attachments/e441ad26-1eb4-492d-abaf-8fcf28c8dbea/西湖豪庭2#2单元603_recover.dxf')
source_doc=ezdxf.readfile(SOURCE)
exec(Path('/workspace/cad-review-r04/materials.py').read_text())

def board(v,x,y,w,h,kind='wood'):
 v.rect(x,y,w,h,'A-OUTLINE',kind,opaque=True)
 v.rect(x+10,y+10,w-20,h-20,'A-DETAIL')

def night(v,x,w):
 board(v,x,0,w,480)
 v.line((x+10,225),(x+w-10,225),'A-DETAIL');v.line((x+70,300),(x+w-70,300),'A-DETAIL')

def headwall(v,w,secondary=False):
 if secondary:
  v.rect(0,500,w,1700,'A-OUTLINE','fabric')
  for i in range(1,4):v.line((w*i/4,500),(w*i/4,2200),'A-DETAIL')
  v.line((0,2220),(w,2220),'A-LIGHT');v.dy(w+180,500,2200,base=w,status='D',source='软饰面高度建议')
  v.tag(60,1700,'M03');v.detail(w-130,2150,'D04')
 else:
  board(v,730,450,2000,800)
  v.tag(900,1150,'M02');v.detail(2520,1200,'D04')

def elevation(index,room,c):
 n=index*4+'ABCD'.index(c)+1;code=f'EL-{n:02}'
 w=room['w'] if c in 'AC' else room['d'];scale=25 if w>4200 else 20
 dirs={'A':'朝原平面上侧','B':'朝原平面右侧','C':'朝原平面下侧','D':'朝原平面左侧'}
 ps=sheet(code,room['name']+' / '+c+' 向立面',f'{dirs[c]} · 平面范围P；构造及新增高度D；未知总高H不补成实测值',f'1:{scale}')
 v=View(n*12000,0,scale,code);frame(v,w)
 materials=['M01 墙面涂装','M02 木作饰面'];details=['D01/D02 柜脚、柜顶','D04 软饰面与木作交接']
 pnote=room['note'].split('。')[0]+'。'
 dnote='柜高、台高、板厚与分格为D建议，详参数及节点。'
 unote='吊顶完成净高H、材料样板及固定条件待确认。'
 if index==0:
  if c=='A':
   headwall(v,w);bed(v,730,2000);night(v,0,730);night(v,2730,730)
   window(v,3880,1120);desk(v,3880,1120)
   v.rect(260,1400,90,160,'A-SYMBOL');v.rect(1280,1580,740,570,'A-DETAIL')
   dimension_chain(v,[0,730,2730,3460,3880,5000,5200],source='9154/9F59/9155/9156及8F72')
   v.dy(540,0,480,base=730,status='D',source='床头柜拟高')
   details=['D04 床头饰面与边框','D06 桌板及窗台协调'];dnote='床头木作上口1250、床头柜480、壁灯中1480为D。'
  elif c=='B':
   window(v,260,3530);desk(v,50,550,side=True)
   dimension_chain(v,[0,260,3790],source='8F71窗线与北侧墙端')
   v.dx(50,600,-350,status='P',source='9156：北端距50，桌深550',component='master_desk_projection_corrected')
   v.txt(750,400,'家具前景不作墙面构件；床体见A向')
   details=['D05 原窗窗套平剖','D07 窗帘盒与吊顶'];dnote='书桌侧投影修正为距北端50、深550；原窗分格U。'
  elif c=='C':
   window(v,300,980)
   dimension_chain(v,[0,300,1280,5200],source='8F3E窗线与房间边界')
   v.tag(1900,1450,'M01');v.txt(1750,1100,'效果图未覆盖区：墙面做法沿用M01设计建议')
   details=['D05 窗口与木饰面收边','D09 踢脚及转角'];dnote='南墙不增设无源门洞；未覆盖墙面仅提出面层建议。'
  else:
   v.line((1050,0),(1050,2400),'A-OUTLINE')
   board(v,1050,80,2740,2320,'fabric')
   for xx in [1080,3730]:v.rect(xx,80,30,2320,'A-DETAIL','wood')
   v.tag(1700,1350,'M03');v.detail(1150,2300,'D04')
   v.txt(80,1100,'通行投影')
   dimension_chain(v,[0,1050,3790],source='914B墙线：1050+2740')
   dnote='织物屏面及木边框按P47意向深化；屏高2400为D。'
   details=['D04 织物板与木边框','D02 顶部收口，H待核']
 elif index==1:
  if c=='A':
   headwall(v,w,True);bed(v,600,1800);night(v,0,600);night(v,2400,1020)
   dimension_chain(v,[0,600,2400,3420],source='9AD0/9AD1及床宽原标')
   for i in range(4):v.dx(w*i/4,w*(i+1)/4,2420,2200,status='D',source='墙面饰面四分格')
   dnote='软饰面从500至2200，四模数855；灯槽位置为D。'
  elif c=='B':
   window(v,260,1500);board(v,260,0,1500,450)
   for xx in [760,1260]:v.line((xx,80),(xx,430),'A-DETAIL')
   dimension_chain(v,[0,260,1760,3430],source='8F42东侧飘窗投影')
   v.txt(1800,1100,'飘窗凸出房间720[P]，详平面索引')
   dnote='飘窗储物座面450为D；开扇、原窗窗台及承托需复核。'
   details=['D05 窗套基层与饰面','D09 座面邻墙收口']
  elif c=='C':
   door(v,70,860);cabinet(v,1020,2400,4,label='次卧薄储物柜',depth=300,source='9AD2')
   dimension_chain(v,[0,70,930,1020,3420],source='916F门扇及9AD2柜体')
   dnote='薄柜深300，内部以层板储物为主；不作常规挂衣柜。'
   details=['JB-03 薄柜内部与剖面','D01/D03 柜脚和门缝']
  else:
   door(v,350,760);window(v,1950,960,inner=True)
   dimension_chain(v,[0,350,1110,1950,2910,3430],source='923C门扇、91C4内窗轮廓')
   dnote='内窗竖向及分格U；以P54纹理玻璃意向深化窗框收口。'
   details=['D05 玻璃窗框与墙面','D09 门套、踢脚交接']
 elif index==2:
  if c=='A':
   shelf(v,3670,600,2300,5,'床头开放侧格','90BE侧投影600')
   cabinet(v,4270,1180,2,label='北侧杂物柜',depth=300,source='90C0')
   bed(v,1620,2050,True,True)
   dimension_chain(v,[0,670,1620,3670,4270,5450],source='原平面完整尺寸链及90BE/90C0')
   dnote='杂物柜原平面深300；床侧屋形与攀爬架按P60意向，非受力图。'
   details=['D08 开放层板灯槽','D01/D02 杂物柜底顶']
   unote+=' 儿童床成品尺寸、攀爬及防倾覆固定需厂家图。'
  elif c=='B':
   door(v,370,860)
   shelf(v,0,1500,2300,4,'床头整合体前景','90BE沿Y1500；距东墙1180')
   v.rect(100,500,1300,700,'A-OUTLINE','fabric',opaque=True)
   v.rect(370,0,860,2250,'A-HIDDEN')
   v.txt(1580,1700,'M01 后方墙面')
   v.txt(60,2440,'前景柜深600[P]；距东墙1180[P]，后方门虚线定位')
   dimension_chain(v,[0,370,1230,3010],source='90DD门扇几何与房间边界')
   v.dx(0,1500,-350,status='P',source='90BE沿Y投影1500',component='girl_head_projection')
   dnote='床头整合体前景遮挡后门；改为开放格及软饰面，拟高2300[D]。'
   details=['D09 门套及墙脚','D04 床头饰面边缘']
  elif c=='C':
   cabinet(v,330,785,1,label='南侧储物柜',source='91CB')
   cabinet(v,1265,2565,5,label='女孩房衣柜',source='91CE')
   door(v,3900,760)
   dimension_chain(v,[0,330,1115,1265,3830,3900,4660,5450],source='91CB/91CE/9110镜像投影')
   dnote='衣柜5个513定位模数；门板缝、内部净宽与剖面详JB-01。'
   details=['JB-01 衣柜内部与侧剖','D01/D02/D03 柜脚、顶、门缝']
  else:
   window(v,630,2380,True)
   desk(v,630,1400)
   board(v,2030,0,980,430);v.rect(2045,430,950,70,'A-DETAIL','fabric')
   v.line((2520,70),(2520,410),'A-DETAIL')
   dimension_chain(v,[0,630,3010],source='90CA组合家具与8F5C窗线')
   v.dx(630,2030,-350,status='D',source='桌/座组合分配1400+980')
   v.dx(2030,3010,-350,status='D',source='桌/座组合分配1400+980')
   v.dy(3330,0,750,base=3010,status='D',source='建议桌高')
   dnote='按P63拆为桌1400+窗边座980[D]，合计保留原轮廓2380[P]。'
   unote='桌面750[D]高于原窗台600[P]共150；窗扇开启未确认，不可下单。'
   details=['D06 桌台/座面/窗台协调','D07 窗帘槽及检修']
 else:
  if c=='A':
   door(v,840,760);shelf(v,2350,3100,600,2,'玩具矮柜','913D')
   for yy in [1200,1630,2060]:m.add_circle(v.p((2500,yy)),95,dxfattribs={'layer':'A-OUTLINE'})
   v.rect(2350,720,280,1680,'A-DETAIL','paint');v.tag(2365,900,'M08')
   dimension_chain(v,[0,840,1600,2350,5450],source='9AB6门扇、913D玩具柜')
   dnote='玩具柜高600[D]；3100原跨度不变。圆饰及蓝色面位置为D意向。'
   details=['JB-03 玩具柜分格','D01/D08 柜底及层板']
  elif c=='B':
   door(v,270,860);cabinet(v,1150,1720,3,label='男孩房衣柜',depth=600,source='90EB')
   # The 20 mm gap is too small for readable chained text: record it in the coordination table.
   v.dx(270,1130,-220,status='P',source='门扇几何860')
   v.dx(1150,2870,-220,status='P',source='90EB沿Y1720')
   v.txt(50,2500,'门扇投影至柜轮廓仅20[P]；门套及侧封板须避让')
   dnote='三定位模数573/574/573；柜侧与门套20余量不足，详JB-02。'
   details=['JB-02 衣柜内部和门套冲突','D03 门板/侧封板平剖']
  elif c=='C':
   bed(v,1400,1500,False,True);desk(v,3400,1380)
   dimension_chain(v,[0,670,1400,2900,3400,4780,5450],source='原床位尺寸及9A77回折桌几何')
   dnote='桌回折段1380[P]，保留与主体2670桌段的转角搭接关系。'
   details=['D06 书桌边部及支承','D04 床头软饰面边框']
   unote+=' 成品床安装及防倾覆由厂家深化。'
  else:
   window(v,130,2540,True);desk(v,0,2670)
   dimension_chain(v,[0,130,2670,2870],source='8F5D窗线/9101桌/913D柜深')
   v.dy(3170,0,750,base=2870,status='D',source='建议桌高')
   dnote='柜后墙深2870；桌及柜前基准2670；不混作同一净深。'
   unote='桌高750[D]与窗台600[P]相差150，开扇范围待核；CH2920不作吊顶净高。'
   details=['D06 原窗与台面高差','D07 窗帘盒及检修']
 notes_panel(ps,[('01 / 材料及做法',materials+['M03 织物/软饰面','M06 地板及踢脚','编码对应GE-01材料表。']),
                 ('02 / 节点索引',details),('03 / 原图与效果依据',[room['pages']+'效果意向。','原DXF几何见GE-02。']),
                 ('04 / 待协调事项',[unote])])
 bottom_info(ps,[('P 原图',pnote),('I 意向',room['pages']+'；图面未覆盖部位列为建议，不冒称效果图已有。'),
                 ('D 深化',dnote),('U 待核','吊顶净高、门窗竖向、饰面选型及连接条件，详GE-00。')])
 viewport(ps,v,(155,165),(278,178),(w/2,1250),scale)
 surface_leaders(ps,w,scale,room['id']+c)


def cover():
 ps=sheet('GE-00','西湖豪庭 / 全部卧室立面深化','R04 · 16个立面 + 柜体内部及剖面 + 9个构造节点','说明')
 txt(ps,20,246,'从平面依据到可编辑立面',6,'S-TEXT')
 lines(ps,20,231,['四间卧室分别设置A/B/C/D向立面；每个立面独立图幅。',
                  '原生尺寸、填充、带属性图块与锁定视口保留于DWG；模型和节点按毫米1:1绘制。'],width=105,h=3,leading=5)
 grid(ps,20,207,[35,170],[("图号","内容"),("GE-00—02","目录、尺寸状态、材料与原平面索引"),
      ("EL-01—04","主卧四向立面"),("EL-05—08","次卧四向立面"),("EL-09—12","女儿房四向立面"),
      ("EL-13—16","男孩房四向立面"),("JB-01—03","衣柜内部、剖面、薄柜与玩具柜深化"),
      ("ND-01—05","D01—D09柜体、饰面、门窗与灯槽节点")],row_h=10)
 txt(ps,241,246,'尺寸状态与适用边界',4,'S-TEXT')
 lines(ps,241,233,['P = 原平面尺寸或可回溯几何。','I = 效果图可见的设计意向。',
   'D = 新增设计建议，可复核和调整。','U = 缺少可靠依据，保持待确认。',
   '竖向未确认段采用省略或折断表达；不以其他项目层高替代本项目H。',
   '门扇几何宽不等于门洞净宽；柜门定位模数不等于净空或下料宽。',
   '尺寸是原生DIMENSION并生成显示块；并非与任意手工修改的轮廓完全关联。'],width=59,h=2.7,leading=4.5)
 txt(ps,20,100,'本版实质修订',4,'S-TEXT')
 lines(ps,20,91,['主卧东向书桌侧投影由距北端600修正为50，深550，源对象9156。',
   '女儿房窗边原家具轮廓2380保留，按P63补为桌1400+座980[D]；取消无源1650桌宽。',
   '女孩房B向取消将前景床头柜误画为三门高柜；男孩房玩具柜回到矮柜意向。',
   '新增衣柜门缝/板厚/净格分别计算、底顶构造、软饰面基层及窗台协调节点。'],width=130,h=2.7,leading=4.8)
 lines(ps,20,49,['待完成：四间完成净高、门窗竖向复测、材料样板与厂家连接审核。',
                 '本版为深化审阅稿；不能作为未经复尺及签审的施工或下料文件。'],width=130,h=2.7,leading=4.8)
 txt(ps,20,32,'灰底用于表示后退面/柜内背板，非材料实际色号；前景遮挡线与材料色号分别核对。',2.7,'S-TEXT')

MATERIALS=[
 ['M01','暖白/浅米墙面','墙面找平/底涂/面涂；基层及品牌待核','P45/54/60/65；I，做法D'],
 ['M02','自然木色木作','柜身18、门板18、封边及五金按柜厂；D','平面轮廓P，面层I/D'],
 ['M03','织物/软饰面','软饰层10+基层12[D]；样板及防火等级待确认','P47/54—56；I，构造D'],
 ['M04','粉/绿织物感斜顶面','织物感来自效果；具体材质样板及成品厂家深化','P60—63/65—67；I'],
 ['M05','保留原窗/纹理内窗','原窗框扇及开启复测；套板12[D]，密封边3[D]','窗宽P；窗高部分P/其余U'],
 ['M06','木地板及踢脚','选材、地面完成厚待核；踢脚高60[D]','效果意向I，做法D'],
 ['M07','吊顶/窗帘盒/灯槽','顶板、龙骨及吊挂专项确认；槽净宽180[D]','意向I，净高及梁底U'],
 ['M08','蓝色哑光装饰面','饰面板/涂装选型待定；圆饰不作结构开洞','P67可见意向I，位置D'],
 ['M09','暖灰哑光柜门面','与M02木色柜身分材质；饰面板/涂装待选型','P60可见哑光意向；D'],
 ['M10','黑色金属感五金','原窗框保留；新增把手及灯具按产品选型','效果可见I；规格U']]

def material_sheet():
 ps=sheet('GE-01','材料编码 / 做法及参数表','同一编码对应一种材料类别；厚度及安装建议均以D标明','说明')
 grid(ps,18,250,[17,55,198,114],[['编码','效果意向','基层 / 面层 / 收口','依据与状态']]+MATERIALS,row_h=14,h=2.7)
 txt(ps,20,83,'统一D参数（不是已确认实测）',3.5,'S-TEXT')
 lines(ps,20,74,['柜高2400；柜身/门板18；门缝3；踢脚80；桌高750、板厚25；窗边座高500。',
   '软饰面10+基层12；木收边3分缝；窗帘槽180净宽×150建议预留深度；灯带选型后复核槽口。',
   '节点示意固定件仅表达连接位置；锚固规格、间距、承载及防火条件由设计/厂家结合基层复核。',
   '儿童房600窗台与750桌面相差150；未取得开扇及现场数据前，该冲突不视为解决。'],width=135,h=2.7,leading=5)

def plan_sheet():
 ps=sheet('GE-02','原平面索引 / 展开方向与几何依据','矢量轮廓摘取自上传DXF；仅用于建立平面投影关系','1:50')
 for j,r in enumerate(ROOMS):
  x0,y0,x1,y1=r['bounds'];ox=j*16000;oy=-10000
  v=View(ox,oy,50,'GE-02')
  # Preserve source WCS geometry in a localized copy; do not edit the source.
  for e in source_doc.modelspace():
   if e.dxftype() not in ['LINE','LWPOLYLINE','ARC','INSERT']:continue
   b=bbox.extents([e],fast=True)
   if not b.has_data or b.extmin.x<x0-200 or b.extmax.x>x1+900 or b.extmin.y<y0-200 or b.extmax.y>y1+200:continue
   if e.dxf.layer in ['DIM','Defpoints']:continue
   for q in disassemble.recursive_decompose([e]):
    if q.dxftype()=='LINE':
     a,bb=q.dxf.start,q.dxf.end;v.line((a.x-x0,a.y-y0),(bb.x-x0,bb.y-y0),'A-DETAIL')
    elif q.dxftype()=='LWPOLYLINE':
     pts=[(p[0]-x0,p[1]-y0) for p in q.get_points()];v.poly(pts,'A-DETAIL',q.closed)
    elif q.dxftype()=='ARC':
     pts=list(q.flattening(10));v.poly([(p.x-x0,p.y-y0) for p in pts])
  rect(m,ox,oy,r['w'],r['d'],'A-PENDING')
  for xx,yy,t in [(r['w']+250,r['d']/2,'B →'),(-500,r['d']/2,'D ←')]:v.txt(xx,yy,t,110)
  cx=110+(j%2)*195;cy=209-(j//2)*94
  viewport(ps,v,(cx,cy),(180,82),(r['w']/2,r['d']/2),50)
  txt(ps,cx,cy+43,'A ↑',2.5,'S-TEXT',align=TextEntityAlignment.CENTER)
  txt(ps,cx,cy-44,'C ↓',2.5,'S-TEXT',align=TextEntityAlignment.CENTER)
  txt(ps,cx-90,cy-50,r['name']+' / '+str(r['w'])+' × '+str(r['d']),3,'S-TEXT')
 lines(ps,20,54,['男孩房2870为柜后墙基准，柜前2670及2690尺寸链端点不同。衣帽间独立区域不在卧室四向范围内。',
   '索引布局保留主要边界和家具投影；源对象与尺寸记录随包附JSON，原上传文件保持只读。'],width=135,h=2.5,leading=4.5)

cover();material_sheet();plan_sheet()
for idx,r in enumerate(ROOMS):
 for c in 'ABCD':elevation(idx,r,c)

# Additional interior fabrication views and construction nodes are separate model geometry.
exec(Path('/workspace/cad-review-r04/details.py').read_text())
path=save();print('SAVED',path,len(SHEETS),'sheets',len(DIMS),'dimensions',flush=True)
